
	function dispHello()
	{
		var str = "Hello World";
		return str;
	}
